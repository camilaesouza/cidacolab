<?php
    return [
        'per_page_default' => 30,
    ];
