Vue.component('filter-text', require('./Text.vue').default)
Vue.component('filter-checkbox', require('./Checkbox.vue').default)
