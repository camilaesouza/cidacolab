<?php
    return [
        'php' => [
            'dateFormat' => 'd/m/Y',
            'dateTimeFormat' => 'd/m/Y H:i',
        ],

        'js' => [
            'dateFormat' => 'dd/mm/yyyy',
            'dateTimeFormat' => 'dd/mm/yyyy',
        ],
    ];
