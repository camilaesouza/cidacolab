<?php
return [

    /**
     * Cabeçalhos, ítens do menu e breadcrumbs devem ficar neste arquivo.
     * Cabeçalhos com nome genérico devem começar com underline.
     */

    '_home' => 'Home',
    '_users' => 'Usuários',

    'users' => [
        'index' => 'Usuários',
        'show' => 'Ver usuário',
        'edit' => 'Editar usuário',
        'create' => 'Cadastrar novo usuário',
    ],
];
