<?php
    /**
     * Cabeçalhos de tabelas e descrição de campos de formulário ficam neste arquivo.
     * Descrições com nome genérico devem começar com underline.
     */

    return [
        //
    ];
