<?php
    /**
     * Descrições de botões e hyperlinks
     */

    return [
        '_new' => 'Novo',
        '_show' => 'Ver',
        '_edit' => 'Editar',
        '_update' => 'Salvar',
        '_destroy' => 'Apagar',
        '_create' => 'Cadastrar',

        'new' => [
            'user' => 'Novo usuário',
        ],
    ];
