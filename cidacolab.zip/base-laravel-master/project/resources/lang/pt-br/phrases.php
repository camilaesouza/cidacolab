<?php
    /**
     * Pequenos trechos de texto, como por exemplo: "Pequena frase descritiva."
     */

    return [
        //
    ];
