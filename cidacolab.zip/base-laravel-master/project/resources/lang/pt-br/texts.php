<?php
    /**
     * Para grandes trechos de texto. Normalmente com várias linhas.
     */

    return [
        //
    ];
