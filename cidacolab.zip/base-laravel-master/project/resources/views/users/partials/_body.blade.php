<td>@{{ item.name }}</td>
<td>@{{ item.email }}</td>
<td>@{{ item.created_at }}</td>
<td>@include('shared.partials._buttons_actions')</td>