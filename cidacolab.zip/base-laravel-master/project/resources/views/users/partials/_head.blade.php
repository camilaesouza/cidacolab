<th sortable @click="orderBy('name', $event)">Nome</th>
<th sortable @click="orderBy('email', $event)">Email</th>
<th sortable @click="orderBy('created_at', $event)">Criado em</th>
<th></th>
