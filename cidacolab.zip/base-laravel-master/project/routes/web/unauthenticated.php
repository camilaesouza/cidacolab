<?php
/**
 * Unauthenticated routes
 */

Auth::routes();

Route::get('/', 'WelcomeController');
