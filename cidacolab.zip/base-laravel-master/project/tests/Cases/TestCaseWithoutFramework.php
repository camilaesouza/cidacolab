<?php

namespace Tests\Cases;

use PHPUnit\Framework\TestCase;

abstract class TestCaseWithoutFramework extends TestCase
{
}
